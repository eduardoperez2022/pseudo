package com.companyname.springbootcrudrest.services;

import com.companyname.springbootcrudrest.model.NoteFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;

@Service
public class NoteService {

    @Autowired
    @Value("${landing.path}")
    private String landingPath;

    public void processData(NoteFile pNote)  {

        saveToLanding(pNote);

    }

    public void saveToLanding(NoteFile pNote) {

        if (pNote.getFileData().length()>0) {
            try {
                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                String timex = "_".concat(timestamp.toString().replace(":","").replace(".","").replace("-","").replace(" ",""));
                StringBuffer sb = new StringBuffer();
                sb.append(landingPath);
                sb.append("/");
                sb.append(pNote.getFileName());
                sb.append(timex);
                sb.append(".csv");
                String fullName = sb.substring(0);
                FileWriter myWriter = new FileWriter(fullName);
                myWriter.write(pNote.getFileData());
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                // e.printStackTrace();
                throw new RuntimeException("Error on saving file.");
            }
        }
    }


}
