package com.companyname.springbootcrudrest.controller;

import com.companyname.springbootcrudrest.model.NoteFile;
import com.companyname.springbootcrudrest.services.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.companyname.springbootcrudrest.repository.UserRepository;

import javax.validation.Valid;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE, path="/api/v1")
public class NoteController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NoteService noteService;


//    @PostMapping(path = "/users", consumes = "application/json", produces = MediaType.APPLICATION_JSON_VALUE)
//    public User createUser(@Valid @RequestBody User user) {
//        return userRepository.save(user);
//    }


    @PostMapping(path = "/notes", consumes = "application/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public String createNote(@Valid @RequestBody NoteFile note) {

        String restVal="-1";

        noteService.processData(note);

        restVal = note.getFileName();

        return restVal;

    }




}
