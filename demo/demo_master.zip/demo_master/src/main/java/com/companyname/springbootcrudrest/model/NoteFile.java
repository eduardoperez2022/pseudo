package com.companyname.springbootcrudrest.model;

import org.springframework.stereotype.Component;

@Component
public class NoteFile {

    private String fileName;
    private String fileData;

    public String getFileName() {
        return fileName;
    }

    public String getFileData() {
        return fileData;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFileData(String fileData) {
        this.fileData = fileData;
    }


}
