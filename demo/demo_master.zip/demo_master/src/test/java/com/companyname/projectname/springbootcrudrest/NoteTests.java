package com.companyname.projectname.springbootcrudrest;

import static org.junit.Assert.assertNotNull;

import com.companyname.springbootcrudrest.model.NoteFile;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

import com.companyname.springbootcrudrest.SpringBootCrudRestApplication;

import java.io.File;
import java.util.Scanner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootCrudRestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class NoteTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String getRootUrl() {
        return "http://localhost:" + port + "/springboot-crud-rest/api/v1/";
    }

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void contextLoads() {

    }

    @Test
    public void testCreateNote1() {

        try {

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            File file = new File("C:/temporal/files/bigfile2.txt");
            Scanner sc = new Scanner(file);

            StringBuffer sb1 = new StringBuffer();

            while (sc.hasNextLine()) {
                sb1.append(sc.nextLine());
                sb1.append('\n');
            }

            NoteFile note1 = new NoteFile();
            note1.setFileName("file5");
            note1.setFileData(sb1.toString());

            HttpEntity<NoteFile> request = new HttpEntity<NoteFile>(note1, headers);

            ResponseEntity<String> responseEntityStr = restTemplate.postForEntity(getRootUrl() + "/notes", request, String.class);

            assertNotNull(responseEntityStr);
            assertNotNull(responseEntityStr.getBody());

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

}
