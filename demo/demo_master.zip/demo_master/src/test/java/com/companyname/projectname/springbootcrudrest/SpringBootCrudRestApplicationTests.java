package com.companyname.projectname.springbootcrudrest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.companyname.springbootcrudrest.model.NoteFile;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.codehaus.jackson.JsonProcessingException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.companyname.springbootcrudrest.SpringBootCrudRestApplication;
import com.companyname.springbootcrudrest.model.User;

import java.io.File;
import java.util.Scanner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootCrudRestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SpringBootCrudRestApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		// return "http://localhost:" + port;
		return "http://localhost:" + port + "/springboot-crud-rest/api/v1/";
	}

	private final ObjectMapper objectMapper = new ObjectMapper();

	@Test
	public void contextLoads() {

	}

	@Test
	public void testGetAllUsers() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/users",
				HttpMethod.GET, entity, String.class);
		
		assertNotNull(response.getBody());
	}

	@Test
	public void testGetUserById() {
		User user = restTemplate.getForObject(getRootUrl() + "/users/1", User.class);
		System.out.println(user.getFirstName());
		assertNotNull(user);
	}

	@Test
	public void testCreateUser() {
		User user = new User();
		user.setEmailId("admin@gmail.com");
		user.setFirstName("admin");
		user.setLastName("admin");
		user.setCreatedBy("admin");
		user.setUpdatedby("admin");


		ResponseEntity<User> postResponse = restTemplate.postForEntity(getRootUrl() + "/users", user, User.class);
		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}



	@Test
	public void testCreateUser3() {

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			User user = new User();
			user.setEmailId("admin@gmail.com");
			user.setFirstName("admin");
			user.setLastName("admin");
			user.setCreatedBy("admin");
			user.setUpdatedby("admin");

			HttpEntity<User> request = new HttpEntity<User>(user, headers);

			ResponseEntity<User> responseEntityStr = restTemplate.postForEntity(getRootUrl() + "/users", request, User.class);

			User bbb = responseEntityStr.getBody();

			assertNotNull(responseEntityStr);
			assertNotNull(responseEntityStr.getBody());

		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


	@Test
	public void testUpdatePost() {
		int id = 1;
		User user = restTemplate.getForObject(getRootUrl() + "/users/" + id, User.class);
		user.setFirstName("admin1");
		user.setLastName("admin2");

		restTemplate.put(getRootUrl() + "/users/" + id, user);

		User updatedUser = restTemplate.getForObject(getRootUrl() + "/users/" + id, User.class);
		assertNotNull(updatedUser);
	}

	@Test
	public void testDeletePost() {
		int id = 2;
		User user = restTemplate.getForObject(getRootUrl() + "/users/" + id, User.class);
		assertNotNull(user);

		restTemplate.delete(getRootUrl() + "/users/" + id);

		try {
			user = restTemplate.getForObject(getRootUrl() + "/users/" + id, User.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}


	@Test
	public void testCreateNote1() {

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			File file = new File("C:/temporal/files/bigfile2.txt");
			Scanner sc = new Scanner(file);

			StringBuffer sb1 = new StringBuffer();

			while (sc.hasNextLine()) {
				sb1.append(sc.nextLine());
				sb1.append('\n');
			}

			NoteFile note1 = new NoteFile();
			note1.setFileName("file5");
			note1.setFileData(sb1.toString());

			HttpEntity<NoteFile> request = new HttpEntity<NoteFile>(note1, headers);

			ResponseEntity<String> responseEntityStr = restTemplate.postForEntity(getRootUrl() + "/notes", request, String.class);

			assertNotNull(responseEntityStr);
			assertNotNull(responseEntityStr.getBody());

		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


}
