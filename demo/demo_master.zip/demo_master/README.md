# springboot-jpa-crud-rest
CRUD Rest APIs using Spring boot 2, JPA, Hibernate 2 and MySQL

http://www.javaguides.net/2018/09/spring-boot-2-hibernate-5-mysql-crud-rest-api-tutorial.html
